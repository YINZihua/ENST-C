/* The content of this file aims at defining user-friendly macros
 * to refer to Unix semaphore names
 */

/* Semaphores names */
#define LOCK_FOR_SHARED_VARIABLES_NAME  "/verrou2012"
#define SEM_FOR_BARRIER_NAME "/barr2012"
